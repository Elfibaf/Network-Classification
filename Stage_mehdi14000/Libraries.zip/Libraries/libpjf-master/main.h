/* Include this file in your main.c */
#include "lib.h"

int debug = 0;
void (*debugcb)() = NULL;
